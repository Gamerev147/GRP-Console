#include "main.h"
#define DLL extern "C" _declspec(dllexport)

RECT rect;
HWND apphwnd=NULL;
HWND game;

DLL double BrowserEmbed(double WindowHandle,HWND game)
{
    apphwnd=FindWindow("BLITZMAX_WINDOW_CLASS","YYWebBrowserYY");

    if ((HWND)(DWORD)WindowHandle!=NULL)
    {
        SetWindowLongPtr((HWND)(DWORD)WindowHandle,GWL_STYLE,GetWindowLong((HWND)(DWORD)WindowHandle,GWL_STYLE)|WS_CLIPCHILDREN|WS_CLIPSIBLINGS);
        GetClientRect((HWND)(DWORD)WindowHandle,&rect);
        if(apphwnd!=NULL)
        {
            ::SetParent(apphwnd,(HWND)(DWORD)WindowHandle);
            ::SetWindowLong(apphwnd, GWL_STYLE, WS_VISIBLE|WS_CHILDWINDOW);
            ::MoveWindow(apphwnd,rect.left,rect.top,rect.right,rect.bottom, true);
        }
    }
    else
    {
        SetWindowLongPtr(game,GWL_STYLE,GetWindowLong(game,GWL_STYLE)|WS_CLIPCHILDREN|WS_CLIPSIBLINGS);
        GetClientRect(game,&rect);
        if(apphwnd!=NULL)
        {
            ::SetParent(apphwnd,game);
            ::SetWindowLong(apphwnd, GWL_STYLE,WS_VISIBLE|WS_CHILDWINDOW);
            ::MoveWindow(apphwnd,rect.left,rect.top,rect.right,rect.bottom, true);
        }
    }
	return 0;
}

DLL double BrowserSetRectangle(double Left,double Top,double Right,double Bottom)
{
    if (apphwnd!=NULL)
	{
        ::MoveWindow(apphwnd,Left,Top,Right,Bottom,true);
	}
	return 0;
}

DLL double BrowserUpdate(double WindowHandle,HWND game)
{
    if ((HWND)(DWORD)WindowHandle!=NULL)
    {
        SetWindowLongPtr((HWND)(DWORD)WindowHandle,GWL_STYLE,GetWindowLong((HWND)(DWORD)WindowHandle,GWL_STYLE)|WS_CLIPCHILDREN|WS_CLIPSIBLINGS);
    }
    else
    {
        SetWindowLongPtr(game,GWL_STYLE,GetWindowLong(game,GWL_STYLE)|WS_CLIPCHILDREN|WS_CLIPSIBLINGS);
    }
    return 0;
}
